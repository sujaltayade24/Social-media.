export interface Message {
  type: string;
  from: number;
  fromUserName: string;
  message: string;
}
