export interface User {
  id: Number,
  userName: String,
  isOnline: Boolean
}
