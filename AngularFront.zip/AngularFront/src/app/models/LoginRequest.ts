export interface LoginRequest {
  name: string;
}
