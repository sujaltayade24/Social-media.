export class Postmodel {
  id: number;
  number: number;
  name: string;
  description: string;
  date:string;
  userName:string;
}
