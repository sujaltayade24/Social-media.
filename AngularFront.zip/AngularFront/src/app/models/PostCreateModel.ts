export class PostCreateModel
{
  name: string;
  description: string;
  date:string;
  userName:string;

}
