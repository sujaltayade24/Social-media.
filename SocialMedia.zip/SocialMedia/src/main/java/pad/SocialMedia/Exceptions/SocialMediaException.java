package pad.SocialMedia.Exceptions;

public class SocialMediaException extends RuntimeException {
    public SocialMediaException(String p) {
        super(p);
    }
}
